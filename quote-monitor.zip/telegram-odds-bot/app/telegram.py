from __future__ import annotations

import html
from typing import Awaitable, Callable

import httpx

from app.models import MARKET_LABELS, Opportunity


class TelegramClient:
    def __init__(self, token: str, chat_ids: set[int]):
        self.base_url = f"https://api.telegram.org/bot{token}"
        self.chat_ids = chat_ids
        self.offset = 0

    async def send(self, text: str) -> None:
        async with httpx.AsyncClient(timeout=20) as client:
            for chat_id in self.chat_ids:
                response = await client.post(
                    f"{self.base_url}/sendMessage",
                    json={"chat_id": chat_id, "text": text, "parse_mode": "HTML", "disable_web_page_preview": True},
                )
                response.raise_for_status()

    async def poll_commands(self, handler: Callable[[str], Awaitable[str]]) -> None:
        async with httpx.AsyncClient(timeout=35) as client:
            response = await client.get(
                f"{self.base_url}/getUpdates",
                params={"offset": self.offset, "timeout": 25, "allowed_updates": '["message"]'},
            )
            response.raise_for_status()
            for update in response.json().get("result", []):
                self.offset = max(self.offset, update["update_id"] + 1)
                message = update.get("message", {})
                chat_id = message.get("chat", {}).get("id")
                text = message.get("text", "")
                if chat_id not in self.chat_ids or not text.startswith("/"):
                    continue
                answer = await handler(text.split()[0].split("@")[0].lower())
                await client.post(
                    f"{self.base_url}/sendMessage",
                    json={"chat_id": chat_id, "text": answer, "parse_mode": "HTML"},
                )


def format_opportunity(item: Opportunity) -> str:
    offers = "\n".join(
        f"• {html.escape(odd.bookmaker.title())}: <b>{odd.odds:.2f}</b>"
        for odd in item.offers
    )
    link = next((odd.url for odd in item.offers if odd.bookmaker == item.best_bookmaker), "")
    action = f'\n<a href="{html.escape(link)}">Apri quota</a>' if link else ""
    return (
        "🔥 <b>Quota interessante</b>\n"
        f"⚽ {html.escape(item.event_name)}\n"
        f"👤 <b>{html.escape(item.player)}</b> — linea {item.line:g}\n"
        f"🎯 {MARKET_LABELS[item.market]}\n"
        f"🏆 Migliore: <b>{html.escape(item.best_bookmaker.title())} {item.best_odds:.2f}</b>\n"
        f"📈 Scarto dalla mediana: <b>+{item.edge_percent:.1f}%</b>\n\n"
        f"{offers}{action}\n\n"
        "⚠️ Confronto informativo: nessuna vincita è garantita."
    )

