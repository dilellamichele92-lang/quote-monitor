from __future__ import annotations

import asyncio
from datetime import datetime, timezone
import logging
import os

from app.engine import find_opportunities
from app.models import MARKET_LABELS, Opportunity
from app.providers import DemoProvider, JsonFeedProvider, OddsProvider
from app.settings import Environment, load_config
from app.storage import Storage
from app.telegram import TelegramClient, format_opportunity


class BotApplication:
    def __init__(self) -> None:
        self.env = Environment()
        self.config = load_config(self.env.config_path)
        self.storage = Storage(self.env.database_path)
        self.telegram = TelegramClient(self.env.telegram_bot_token, self.env.chat_ids)
        self.providers = self._build_providers()
        self.latest: list[Opportunity] = []
        self.last_run: datetime | None = None
        self.last_odds_count = 0
        self.paused = False

    def _build_providers(self) -> list[OddsProvider]:
        if self.config.demo_mode:
            return [
                DemoProvider("goldbet", 0.18),
                DemoProvider("domusbet", 0.00),
                DemoProvider("betwin360", -0.08),
            ]
        providers: list[OddsProvider] = []
        for name, bookmaker in self.config.bookmakers.items():
            url = os.getenv(bookmaker.url_env, "")
            token = os.getenv(bookmaker.token_env, "")
            if bookmaker.enabled and url:
                providers.append(JsonFeedProvider(name, url, token, self.config.request_timeout_seconds))
        if not providers:
            raise RuntimeError("Nessun feed configurato: imposta almeno una variabile *_FEED_URL")
        return providers

    async def odds_cycle(self) -> None:
        batches = await asyncio.gather(
            *(provider.fetch() for provider in self.providers), return_exceptions=True
        )
        odds = []
        for provider, batch in zip(self.providers, batches):
            if isinstance(batch, Exception):
                logging.error("Errore provider %s: %s", provider.name, batch)
            else:
                odds.extend(item for item in batch if item.market in self.config.markets)
        self.last_run = datetime.now(timezone.utc)
        self.last_odds_count = len(odds)
        self.latest = find_opportunities(odds, self.config.alerts)
        if self.paused:
            return
        for item in self.latest:
            if self.storage.should_alert(
                item,
                self.config.alerts.cooldown_minutes,
                self.config.alerts.min_change_percent,
            ):
                await self.telegram.send(format_opportunity(item))
                self.storage.mark_alerted(item)

    async def handle_command(self, command: str) -> str:
        if command in {"/start", "/help"}:
            return (
                "<b>Odds Tracker</b>\n"
                "/status — stato del monitor\n/best — migliori quote\n"
                "/pause — sospendi avvisi\n/resume — riattiva avvisi"
            )
        if command == "/pause":
            self.paused = True
            return "⏸ Notifiche sospese."
        if command == "/resume":
            self.paused = False
            return "▶️ Notifiche riattivate."
        if command == "/status":
            last = self.last_run.strftime("%d/%m/%Y %H:%M:%S UTC") if self.last_run else "mai"
            return (
                f"Stato: {'in pausa' if self.paused else 'attivo'}\n"
                f"Ultimo controllo: {last}\nQuote lette: {self.last_odds_count}\n"
                f"Opportunità: {len(self.latest)}\nModalità demo: {self.config.demo_mode}"
            )
        if command == "/best":
            if not self.latest:
                return "Nessuna opportunità sopra le soglie nell'ultimo controllo."
            lines = ["<b>Migliori opportunità</b>"]
            for item in self.latest[:10]:
                lines.append(
                    f"• {item.player} — {MARKET_LABELS[item.market]}: "
                    f"<b>{item.best_bookmaker.title()} {item.best_odds:.2f}</b> "
                    f"(+{item.edge_percent:.1f}%)"
                )
            return "\n".join(lines)
        return "Comando non riconosciuto. Usa /help."

    async def run(self) -> None:
        await self.telegram.send("✅ Odds Tracker avviato. Usa /status per controllarlo.")

        async def monitor() -> None:
            while True:
                try:
                    await self.odds_cycle()
                except Exception:
                    logging.exception("Errore nel ciclo quote")
                await asyncio.sleep(self.config.poll_interval_seconds)

        async def commands() -> None:
            while True:
                try:
                    await self.telegram.poll_commands(self.handle_command)
                except Exception:
                    logging.exception("Errore nel polling Telegram")
                    await asyncio.sleep(5)

        await asyncio.gather(monitor(), commands())


def main() -> None:
    environment = Environment()
    logging.basicConfig(
        level=getattr(logging, environment.log_level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    asyncio.run(BotApplication().run())


if __name__ == "__main__":
    main()
