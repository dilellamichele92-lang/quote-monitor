from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
import sqlite3

from app.models import Opportunity


class Storage:
    def __init__(self, path: str):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(path)
        self.connection.execute(
            """CREATE TABLE IF NOT EXISTS alerts (
            selection_key TEXT PRIMARY KEY,
            best_odds REAL NOT NULL,
            sent_at TEXT NOT NULL
            )"""
        )
        self.connection.commit()

    def should_alert(
        self, opportunity: Opportunity, cooldown_minutes: int, min_change_percent: float
    ) -> bool:
        row = self.connection.execute(
            "SELECT best_odds, sent_at FROM alerts WHERE selection_key = ?",
            (opportunity.selection_key,),
        ).fetchone()
        if row is None:
            return True
        previous_odds, sent_at_raw = row
        sent_at = datetime.fromisoformat(sent_at_raw)
        change = abs((opportunity.best_odds / previous_odds - 1) * 100)
        cooldown_over = datetime.now(timezone.utc) >= sent_at + timedelta(minutes=cooldown_minutes)
        return cooldown_over or change >= min_change_percent

    def mark_alerted(self, opportunity: Opportunity) -> None:
        self.connection.execute(
            """INSERT INTO alerts(selection_key, best_odds, sent_at) VALUES (?, ?, ?)
            ON CONFLICT(selection_key) DO UPDATE SET best_odds=excluded.best_odds,
            sent_at=excluded.sent_at""",
            (opportunity.selection_key, opportunity.best_odds, datetime.now(timezone.utc).isoformat()),
        )
        self.connection.commit()

