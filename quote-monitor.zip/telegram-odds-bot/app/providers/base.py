from typing import Protocol

from app.models import Odd


class OddsProvider(Protocol):
    name: str

    async def fetch(self) -> list[Odd]: ...

