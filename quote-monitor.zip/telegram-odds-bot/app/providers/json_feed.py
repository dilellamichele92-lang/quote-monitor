from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import httpx

from app.models import Market, Odd


class JsonFeedProvider:
    def __init__(self, name: str, url: str, token: str = "", timeout: float = 20):
        self.name = name
        self.url = url
        self.token = token
        self.timeout = timeout

    async def fetch(self) -> list[Odd]:
        headers = {"Accept": "application/json", "User-Agent": "OddsTracker/1.0"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        async with httpx.AsyncClient(timeout=self.timeout, follow_redirects=True) as client:
            response = await client.get(self.url, headers=headers)
            response.raise_for_status()
            payload = response.json()
        rows = payload.get("odds", []) if isinstance(payload, dict) else payload
        return [self._parse(row) for row in rows]

    def _parse(self, row: dict[str, Any]) -> Odd:
        start = datetime.fromisoformat(str(row["start_time"]).replace("Z", "+00:00"))
        if start.tzinfo is None:
            start = start.replace(tzinfo=timezone.utc)
        return Odd(
            bookmaker=self.name,
            event_id=str(row.get("event_id", "")),
            event_name=str(row["event_name"]),
            start_time=start,
            market=Market(str(row["market"])),
            player=str(row["player"]),
            line=float(row.get("line", 0.5)),
            odds=float(row["odds"]),
            url=str(row.get("url", "")),
            observed_at=datetime.now(timezone.utc),
        )

