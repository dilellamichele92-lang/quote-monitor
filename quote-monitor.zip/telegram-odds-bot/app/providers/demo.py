from __future__ import annotations

from datetime import datetime, timedelta, timezone
import random

from app.models import Market, Odd


class DemoProvider:
    def __init__(self, name: str, offset: float = 0):
        self.name = name
        self.offset = offset

    async def fetch(self) -> list[Odd]:
        now = datetime.now(timezone.utc)
        rng = random.Random(int(now.timestamp() // 300) + sum(map(ord, self.name)))
        samples = [
            (Market.SCORER_PLUS, "Luca Bianchi", 0.5, 2.35),
            (Market.ALMOST_CARDED_PLUS, "Marco Verdi", 0.5, 1.95),
            (Market.CARDED_PLUS, "Paolo Neri", 0.5, 2.65),
            (Market.FIRST_HALF_SCORER, "Luca Bianchi", 0.5, 4.80),
            (Market.SHOT_ON_TARGET_PLUS, "Andrea Blu", 1.5, 2.05),
        ]
        return [
            Odd(
                bookmaker=self.name,
                event_id="demo-milan-roma",
                event_name="Milan - Roma (DEMO)",
                start_time=now + timedelta(hours=3),
                market=market,
                player=player,
                line=line,
                odds=round(base + self.offset + rng.uniform(-0.05, 0.05), 2),
                url="",
                observed_at=now,
            )
            for market, player, line, base in samples
        ]

