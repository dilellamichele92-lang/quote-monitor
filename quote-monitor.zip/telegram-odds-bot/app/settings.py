from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from app.models import Market


class AlertConfig(BaseModel):
    min_odds: float = Field(1.70, gt=1)
    min_edge_percent: float = Field(5, ge=0)
    min_change_percent: float = Field(2, ge=0)
    cooldown_minutes: int = Field(30, ge=0)
    require_bookmakers: int = Field(2, ge=1)


class BookmakerConfig(BaseModel):
    enabled: bool = True
    url_env: str
    token_env: str


class AppConfig(BaseModel):
    poll_interval_seconds: int = Field(60, ge=10)
    request_timeout_seconds: int = Field(20, ge=1)
    demo_mode: bool = True
    alerts: AlertConfig = AlertConfig()
    markets: list[Market]
    bookmakers: dict[str, BookmakerConfig]


class Environment(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    telegram_bot_token: str
    telegram_chat_ids: str
    config_path: str = "config.yaml"
    database_path: str = "data/odds.db"
    log_level: str = "INFO"

    @property
    def chat_ids(self) -> set[int]:
        return {int(item.strip()) for item in self.telegram_chat_ids.split(",") if item.strip()}


def load_config(path: str) -> AppConfig:
    raw: dict[str, Any] = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    return AppConfig.model_validate(raw)

