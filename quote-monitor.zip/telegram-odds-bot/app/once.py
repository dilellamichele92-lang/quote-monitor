"""Esegue un solo ciclo, adatto a GitHub Actions e cron."""

import asyncio
import logging

from app.main import BotApplication
from app.settings import Environment


async def run_once() -> None:
    application = BotApplication()
    await application.odds_cycle()
    logging.info(
        "Controllo completato: %s quote, %s opportunità",
        application.last_odds_count,
        len(application.latest),
    )


def main() -> None:
    environment = Environment()
    logging.basicConfig(
        level=getattr(logging, environment.log_level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    asyncio.run(run_once())


if __name__ == "__main__":
    main()

