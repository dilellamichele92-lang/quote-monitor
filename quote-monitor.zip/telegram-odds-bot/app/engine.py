from __future__ import annotations

from collections import defaultdict
from statistics import median
from typing import Protocol

from app.models import Odd, Opportunity


class AlertRules(Protocol):
    min_odds: float
    min_edge_percent: float
    require_bookmakers: int


def find_opportunities(odds: list[Odd], config: AlertRules) -> list[Opportunity]:
    grouped: dict[str, list[Odd]] = defaultdict(list)
    for odd in odds:
        if odd.odds > 1:
            grouped[odd.selection_key].append(odd)

    result: list[Opportunity] = []
    for key, offers in grouped.items():
        latest_by_bookmaker: dict[str, Odd] = {}
        for offer in offers:
            current = latest_by_bookmaker.get(offer.bookmaker)
            if current is None or offer.observed_at > current.observed_at:
                latest_by_bookmaker[offer.bookmaker] = offer
        comparable = list(latest_by_bookmaker.values())
        if len(comparable) < config.require_bookmakers:
            continue
        best = max(comparable, key=lambda item: item.odds)
        reference = median(item.odds for item in comparable)
        edge = ((best.odds / reference) - 1) * 100 if reference else 0
        if best.odds < config.min_odds or edge < config.min_edge_percent:
            continue
        ordered = tuple(sorted(comparable, key=lambda item: item.odds, reverse=True))
        result.append(
            Opportunity(
                selection_key=key,
                event_name=best.event_name,
                start_time=best.start_time,
                market=best.market,
                player=best.player,
                line=best.line,
                best_bookmaker=best.bookmaker,
                best_odds=best.odds,
                reference_odds=reference,
                edge_percent=edge,
                offers=ordered,
            )
        )
    return sorted(result, key=lambda item: item.edge_percent, reverse=True)
