from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import StrEnum
import re
import unicodedata


class Market(StrEnum):
    SCORER_PLUS = "scorer_plus"
    ALMOST_CARDED_PLUS = "almost_carded_plus"
    CARDED_PLUS = "carded_plus"
    FIRST_HALF_SCORER = "first_half_scorer"
    SHOT_ON_TARGET_PLUS = "shot_on_target_plus"


MARKET_LABELS = {
    Market.SCORER_PLUS: "Marcatore Plus",
    Market.ALMOST_CARDED_PLUS: "Quasi ammonito Plus",
    Market.CARDED_PLUS: "Ammonito Plus",
    Market.FIRST_HALF_SCORER: "Marcatore 1° tempo",
    Market.SHOT_ON_TARGET_PLUS: "Tiro in porta Plus",
}


def normalize(value: str) -> str:
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()


@dataclass(frozen=True, slots=True)
class Odd:
    bookmaker: str
    event_id: str
    event_name: str
    start_time: datetime
    market: Market
    player: str
    line: float
    odds: float
    url: str = ""
    observed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def selection_key(self) -> str:
        event = normalize(self.event_id or self.event_name)
        return f"{event}|{self.market.value}|{normalize(self.player)}|{self.line:g}"


@dataclass(frozen=True, slots=True)
class Opportunity:
    selection_key: str
    event_name: str
    start_time: datetime
    market: Market
    player: str
    line: float
    best_bookmaker: str
    best_odds: float
    reference_odds: float
    edge_percent: float
    offers: tuple[Odd, ...]
