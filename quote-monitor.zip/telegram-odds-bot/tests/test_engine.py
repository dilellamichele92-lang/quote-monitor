from datetime import datetime, timezone
from types import SimpleNamespace
import unittest

from app.engine import find_opportunities
from app.models import Market, Odd


def odd(bookmaker: str, price: float) -> Odd:
    return Odd(
        bookmaker=bookmaker,
        event_id="milan-roma",
        event_name="Milan - Roma",
        start_time=datetime(2026, 9, 20, 18, 45, tzinfo=timezone.utc),
        market=Market.SHOT_ON_TARGET_PLUS,
        player="Mario Rossi",
        line=0.5,
        odds=price,
        observed_at=datetime.now(timezone.utc),
    )


def rules(edge: float = 5, required: int = 2) -> SimpleNamespace:
    return SimpleNamespace(min_odds=1.7, min_edge_percent=edge, require_bookmakers=required)


class EngineTests(unittest.TestCase):
    def test_finds_best_quote_above_edge(self) -> None:
        result = find_opportunities(
            [odd("goldbet", 2.20), odd("domusbet", 1.90), odd("betwin360", 1.92)],
            rules(),
        )
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].best_bookmaker, "goldbet")
        self.assertEqual(result[0].best_odds, 2.20)

    def test_rejects_small_difference(self) -> None:
        result = find_opportunities(
            [odd("goldbet", 2.00), odd("domusbet", 1.98), odd("betwin360", 1.99)],
            rules(),
        )
        self.assertEqual(result, [])

    def test_requires_multiple_bookmakers(self) -> None:
        result = find_opportunities([odd("goldbet", 2.20)], rules(edge=0, required=2))
        self.assertEqual(result, [])


if __name__ == "__main__":
    unittest.main()
