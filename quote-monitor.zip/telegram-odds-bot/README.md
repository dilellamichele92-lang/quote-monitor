# Telegram Odds Bot

Bot Telegram che confronta quote relative ai calciatori fra GoldBet, DomusBet e
Betwin360 e segnala la quota più alta per la stessa selezione.

Mercati inclusi:

- marcatore plus (`scorer_plus`)
- quasi ammonito plus (`almost_carded_plus`)
- ammonito plus (`carded_plus`)
- marcatore primo tempo (`first_half_scorer`)
- tiro in porta plus (`shot_on_target_plus`)

## Cosa significa “appetibile”

Per ogni evento, giocatore, mercato e linea, il bot calcola la mediana delle
quote disponibili. Invia un avviso quando:

1. ci sono quote da almeno `require_bookmakers` operatori;
2. la quota migliore è almeno `min_odds`;
3. supera la mediana di almeno `min_edge_percent`;
4. non è già stata notificata nel cooldown, salvo una variazione di almeno
   `min_change_percent`.

Questi criteri identificano una differenza di prezzo, non garantiscono valore o
vincite. Verifica termini d'uso, licenze e accesso autorizzato ai feed.

## Avvio rapido in modalità demo

1. Crea un bot con BotFather e recupera token e chat ID.
2. Copia `.env.example` in `.env` e compila i due valori Telegram.
3. Avvia:

```bash
docker compose up --build -d
```

La modalità demo genera quote sintetiche e consente di verificare notifiche,
persistenza e comandi. Per produzione imposta `demo_mode: false`.

## Esecuzione gratuita con GitHub Actions

Il workflow `.github/workflows/monitor.yml` esegue un controllo ogni cinque
minuti. In **Settings → Secrets and variables → Actions** aggiungi almeno:

- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_CHAT_IDS`

Per le quote reali aggiungi anche `GOLDBET_FEED_URL`, `DOMUSBET_FEED_URL` e
`BETWIN360_FEED_URL`, più gli eventuali token API. Il workflow usa
`config.production.yaml`, che disabilita esplicitamente i dati demo. Se i
secret Telegram mancano, termina senza errori e senza inviare messaggi.

GitHub può ritardare le esecuzioni pianificate. Il bot in questa modalità non
gestisce i comandi Telegram in tempo reale: esegue soltanto confronto e avvisi.

## Collegamento dei feed reali

Imposta le variabili `*_FEED_URL` e, se richiesto, `*_API_TOKEN`. Ogni endpoint
deve restituire JSON come array diretto oppure sotto la chiave `odds`:

```json
{
  "odds": [
    {
      "event_id": "seriea-2026-09-20-milan-roma",
      "event_name": "Milan - Roma",
      "start_time": "2026-09-20T18:45:00Z",
      "market": "shot_on_target_plus",
      "player": "Mario Rossi",
      "line": 0.5,
      "odds": 2.10,
      "url": "https://bookmaker.example/evento"
    }
  ]
}
```

Il token viene inviato come `Authorization: Bearer ...`. Se il formato reale è
diverso, modifica soltanto `app/providers/json_feed.py`, lasciando invariato il
motore di confronto.

## Comandi Telegram

- `/start` e `/help`: guida rapida
- `/status`: stato, ultimo ciclo e numero quote
- `/best`: migliori opportunità viste nell'ultimo ciclo
- `/pause`: sospende le notifiche
- `/resume`: riattiva le notifiche

Solo gli ID presenti in `TELEGRAM_CHAT_IDS` ricevono notifiche e possono usare i
comandi.

## Esecuzione senza Docker

```bash
python -m venv .venv
. .venv/bin/activate
pip install -e '.[dev]'
cp .env.example .env
python -m app.main
```

## Test

```bash
python -m unittest discover -s tests -v
```

## Note importanti

- Il progetto non aggira login, CAPTCHA, geoblocchi o protezioni tecniche.
- Preferisci API/feed ufficiali o autorizzati. Lo scraping HTML non è incluso
  perché instabile e potenzialmente contrario ai termini dei siti.
- Il gioco comporta rischio economico. Imposta limiti e usa il bot soltanto dove
  consentito dalla legge e dai termini degli operatori.
